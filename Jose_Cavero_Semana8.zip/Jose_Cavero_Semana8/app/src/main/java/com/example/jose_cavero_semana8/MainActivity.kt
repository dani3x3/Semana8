package com.example.jose_cavero_semana8

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTextNumero1 = findViewById<EditText>(R.id.editTextNumero1)
        val editTextNumero2 = findViewById<EditText>(R.id.editTextNumero2)
        val radioGroup = findViewById<RadioGroup>(R.id.radioGroup)
        val buttonSumar = findViewById<Button>(R.id.buttonSumar)
        val buttonRestar = findViewById<Button>(R.id.buttonRestar)
        val buttonTransformar = findViewById<Button>(R.id.buttonTransformar)
        val textViewResultado = findViewById<TextView>(R.id.textViewResultado)

        buttonSumar.setOnClickListener {
            val numero1 = editTextNumero1.text.toString().toIntOrNull()
            val numero2 = editTextNumero2.text.toString().toIntOrNull()

            if (numero1 != null && numero2 != null) {
                val resultado = sumar(numero1, numero2, radioGroup.checkedRadioButtonId)
                textViewResultado.text = resultado.toString()
            } else {
                Toast.makeText(this, "Ingrese un número válido", Toast.LENGTH_SHORT).show()
            }
        }

        buttonRestar.setOnClickListener {
            val numero1 = editTextNumero1.text.toString().toIntOrNull()
            val numero2 = editTextNumero2.text.toString().toIntOrNull()

            if (numero1 != null && numero2 != null) {
                val resultado = restar(numero1, numero2, radioGroup.checkedRadioButtonId)
                textViewResultado.text = resultado.toString()
            } else {
                Toast.makeText(this, "Ingrese un número válido", Toast.LENGTH_SHORT).show()
            }
        }

        buttonTransformar.setOnClickListener {
            val numero = editTextNumero1.text.toString().toIntOrNull()

            if (numero != null) {
                val textoTransformado = transformar(numero, radioGroup.checkedRadioButtonId)
                textViewResultado.text = textoTransformado
            } else {
                Toast.makeText(this, "Ingrese un número válido", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sumar(numero1: Int, numero2: Int, sistema: Int): Int {
        return when (sistema) {
            R.id.radioButtonDecimal -> numero1 + numero2
            R.id.radioButtonBinario -> sumarBinario(numero1.toString(2), numero2.toString(2))
            else -> 0
        }
    }

    private fun restar(numero1: Int, numero2: Int, sistema: Int): Int {
        return when (sistema) {
            R.id.radioButtonDecimal -> numero1 - numero2
            R.id.radioButtonBinario -> restarBinario(numero1.toString(2), numero2.toString(2))
            else -> 0
        }
    }

    private fun transformar(numero: Int, sistema: Int): String {
        return when (sistema) {
            R.id.radioButtonDecimal -> numero.toString()
            R.id.radioButtonBinario -> Integer.toString(numero, 2)
            else -> ""
        }
    }

    private fun sumarBinario(binario1: String, binario2: String): Int {
        val numero1 = binario1.toInt(2)
        val numero2 = binario2.toInt(2)
        return numero1 + numero2
    }

    private fun restarBinario(binario1: String, binario2: String): Int {
        val numero1 = binario1.toInt(2)
        val numero2 = binario2.toInt(2)
        return numero1 - numero2
    }
}
